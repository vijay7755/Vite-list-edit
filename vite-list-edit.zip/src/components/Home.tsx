function Home() {
    return <div>
        <h1>Number Converter</h1>
    </div>
}

export default Home